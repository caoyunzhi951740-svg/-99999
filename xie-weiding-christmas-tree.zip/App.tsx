import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Loader } from '@react-three/drei';
import { TreeMorphState } from './types';
import Experience from './components/Experience';
import Overlay from './components/Overlay';

const App: React.FC = () => {
  const [treeState, setTreeState] = useState<TreeMorphState>(TreeMorphState.SCATTERED);

  const toggleState = () => {
    setTreeState((prev) => 
      prev === TreeMorphState.TREE_SHAPE ? TreeMorphState.SCATTERED : TreeMorphState.TREE_SHAPE
    );
  };

  return (
    <div className="relative w-full h-full bg-[#05100e]">
      <Canvas
        shadows
        camera={{ position: [0, 2, 12], fov: 45 }}
        dpr={[1, 2]}
        gl={{ antialias: false, toneMappingExposure: 1.5 }}
      >
        <Suspense fallback={null}>
          <Experience treeState={treeState} />
        </Suspense>
      </Canvas>
      
      <Loader 
        containerStyles={{ backgroundColor: '#022c22' }}
        innerStyles={{ width: '200px', backgroundColor: '#333' }}
        barStyles={{ backgroundColor: '#d4af37', height: '2px' }}
        dataStyles={{ fontFamily: '"Playfair Display", serif', color: '#d4af37' }}
      />
      
      <Overlay treeState={treeState} onToggle={toggleState} />
    </div>
  );
};

export default App;