import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';

const Snowfall: React.FC = () => {
  const count = 400; // Sparse
  const mesh = useRef<THREE.Points>(null);
  
  // Create initial random positions
  const [positions, speeds] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const spd = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 40;     // x: wide range
      pos[i * 3 + 1] = (Math.random() - 0.5) * 40; // y: tall range
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20; // z: depth
      spd[i] = 0.5 + Math.random() * 1.5;          // random falling speed
    }
    return [pos, spd];
  }, []);

  useFrame((_, delta) => {
    if (!mesh.current) return;
    
    const positionsAttribute = mesh.current.geometry.getAttribute('position');
    
    for (let i = 0; i < count; i++) {
      let y = positionsAttribute.getY(i);
      
      // Move down
      y -= speeds[i] * delta;

      // Reset to top if too low
      if (y < -15) {
        y = 20;
        // Randomize X and Z again slightly to break patterns
        positionsAttribute.setX(i, (Math.random() - 0.5) * 40);
        positionsAttribute.setZ(i, (Math.random() - 0.5) * 20);
      }

      positionsAttribute.setY(i, y);
    }
    
    positionsAttribute.needsUpdate = true;
  });

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.15}
        color="#ffffff"
        transparent
        opacity={0.6}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};

export default Snowfall;