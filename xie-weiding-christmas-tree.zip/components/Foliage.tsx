import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { TreeMorphState } from '../types';

// Shader for the particles
const vertexShader = `
  uniform float uTime;
  uniform float uMix;
  
  attribute vec3 aTreePos;
  attribute vec3 aScatterPos;
  attribute float aRandom;

  varying float vAlpha;
  varying vec3 vColor;

  // Simplex noise function (simplified)
  vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
  vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

  float snoise(vec3 v) {
    const vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
    const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i  = floor(v + dot(v, C.yyy) );
    vec3 x0 = v - i + dot(i, C.xxx) ;
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min( g.xyz, l.zxy );
    vec3 i2 = max( g.xyz, l.zxy );
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy; // 2.0*C.x = 1/3 = C.y
    vec3 x3 = x0 - D.yyy;      // -1.0+3.0*C.x = -0.5 = -D.y
    i = mod289(i); 
    vec4 p = permute( permute( permute( 
              i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0 )) 
            + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));
    float n_ = 0.142857142857; // 1.0/7.0
    vec3  ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);  //  mod(p,7*7)
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_ );    // mod(j,N)
    vec4 x = x_ *ns.x + ns.yyyy;
    vec4 y = y_ *ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4( x.xy, y.xy );
    vec4 b1 = vec4( x.zw, y.zw );
    vec4 s0 = floor(b0)*2.0 + 1.0;
    vec4 s1 = floor(b1)*2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;
    vec3 p0 = vec3(a0.xy,h.x);
    vec3 p1 = vec3(a0.zw,h.y);
    vec3 p2 = vec3(a1.xy,h.z);
    vec3 p3 = vec3(a1.zw,h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1), 
                                  dot(p2,x2), dot(p3,x3) ) );
  }

  void main() {
    // Cubic easing for mix
    float t = uMix;
    float ease = t < 0.5 ? 4.0 * t * t * t : 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0;

    vec3 pos = mix(aScatterPos, aTreePos, ease);
    
    // Add "breathing" noise
    float breathing = snoise(pos * 0.5 + uTime * 0.5) * 0.1;
    pos += normalize(pos) * breathing * (0.2 + 0.8 * ease); // Breath more when assembled

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    
    gl_Position = projectionMatrix * mvPosition;
    
    // Size attenuation
    gl_PointSize = (40.0 * aRandom + 20.0) * (1.0 / -mvPosition.z);
    
    // Pass color info
    vAlpha = 0.6 + 0.4 * sin(uTime * 2.0 + aRandom * 10.0);
    
    // Mix between dark emerald and a hint of gold based on noise
    vec3 emerald = vec3(0.01, 0.2, 0.1);
    vec3 gold = vec3(1.0, 0.8, 0.4);
    float noiseVal = snoise(pos * 2.0);
    vColor = mix(emerald, gold, smoothstep(0.6, 1.0, noiseVal));
  }
`;

const fragmentShader = `
  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    // Circular particle
    vec2 cxy = 2.0 * gl_PointCoord - 1.0;
    float r = dot(cxy, cxy);
    if (r > 1.0) discard;

    // Soft edge
    float delta = fwidth(r);
    float alpha = 1.0 - smoothstep(1.0 - delta, 1.0 + delta, r);

    // Glow center
    float glow = 1.0 - r;
    glow = pow(glow, 1.5);

    gl_FragColor = vec4(vColor * 1.5, vAlpha * alpha * glow);
    
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

interface FoliageProps {
  treeState: TreeMorphState;
}

const Foliage: React.FC<FoliageProps> = ({ treeState }) => {
  const count = 12000;
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  const [positions, scatterPositions, randoms] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const scatter = new Float32Array(count * 3);
    const rand = new Float32Array(count);

    const height = 10;
    const baseRadius = 4;

    for (let i = 0; i < count; i++) {
      // Tree shape (Cone with volume)
      const y = Math.random() * height; // 0 to 10
      const relativeY = y / height; // 0 to 1 (bottom to top)
      const r = (1 - relativeY) * baseRadius; // Radius decreases as we go up
      
      // Volume distribution (random radius within the cone slice)
      const radius = Math.sqrt(Math.random()) * r; 
      const theta = Math.random() * Math.PI * 2;

      const x = radius * Math.cos(theta);
      const z = radius * Math.sin(theta);

      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;

      // Scatter Shape (Sphere/Cloud)
      const sr = 15 + Math.random() * 5; // Large radius
      const sTheta = Math.random() * Math.PI * 2;
      const sPhi = Math.acos(2 * Math.random() - 1);
      
      scatter[i * 3] = sr * Math.sin(sPhi) * Math.cos(sTheta);
      scatter[i * 3 + 1] = sr * Math.sin(sPhi) * Math.sin(sTheta);
      scatter[i * 3 + 2] = sr * Math.cos(sPhi);

      rand[i] = Math.random();
    }
    return [pos, scatter, rand];
  }, []);

  useFrame((state, delta) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      
      const targetMix = treeState === TreeMorphState.TREE_SHAPE ? 1 : 0;
      // Smooth lerp for the uMix uniform
      materialRef.current.uniforms.uMix.value = THREE.MathUtils.lerp(
        materialRef.current.uniforms.uMix.value,
        targetMix,
        delta * 2 // Speed of transition
      );
    }
  });

  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uMix: { value: 0 },
  }), []);

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position" // This is actually unused by shader logic (we use aTreePos), but required for raycasting/bounding
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTreePos"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aScatterPos"
          count={scatterPositions.length / 3}
          array={scatterPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          count={randoms.length}
          array={randoms}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default Foliage;