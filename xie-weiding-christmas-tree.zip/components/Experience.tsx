import React from 'react';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { TreeMorphState } from '../types';
import ChristmasTree from './ChristmasTree';
import Snowfall from './Snowfall';

interface ExperienceProps {
  treeState: TreeMorphState;
}

const Experience: React.FC<ExperienceProps> = ({ treeState }) => {
  return (
    <>
      {/* Moved camera back to 22 to make the tree smaller in frame */}
      <PerspectiveCamera makeDefault position={[0, 0, 22]} fov={45} />
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 3} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={8}
        maxDistance={40}
        autoRotate={treeState === TreeMorphState.TREE_SHAPE}
        autoRotateSpeed={0.5}
        dampingFactor={0.05}
      />

      {/* Lighting - Luxury Setup */}
      <ambientLight intensity={0.2} color="#001a10" />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.2} 
        penumbra={1} 
        intensity={2} 
        color="#ffecd1" 
        castShadow 
      />
      <pointLight position={[-10, 5, -10]} intensity={1} color="#00ff88" distance={20} />
      <pointLight position={[0, -5, 5]} intensity={0.5} color="#d4af37" distance={10} />

      {/* Environment Reflections */}
      <Environment preset="city" background={false} blur={0.8} />

      {/* Main Object - Moved down to center the tree volume (height ~10) around the origin */}
      <group position={[0, -5, 0]}>
        <ChristmasTree treeState={treeState} />
      </group>

      {/* Global Snowfall - Independent of Tree transform */}
      <Snowfall />

      {/* Cinematic Post Processing */}
      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.8} 
          mipmapBlur 
          intensity={1.2} 
          radius={0.6}
        />
        <Vignette offset={0.3} darkness={0.6} eskil={false} />
        <Noise opacity={0.02} blendFunction={BlendFunction.OVERLAY} />
      </EffectComposer>
    </>
  );
};

export default Experience;