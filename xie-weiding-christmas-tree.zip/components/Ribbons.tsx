import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { TreeMorphState } from '../types';

// Reuse the foliage shader logic but tailored for ribbon colors
const vertexShader = `
  uniform float uTime;
  uniform float uMix;
  
  attribute vec3 aTreePos;
  attribute vec3 aScatterPos;
  attribute vec3 aColor; 
  attribute float aRandom;

  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    // Cubic easing
    float t = uMix;
    float ease = t < 0.5 ? 4.0 * t * t * t : 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0;

    vec3 pos = mix(aScatterPos, aTreePos, ease);
    
    // Gentle flow animation along the ribbon path
    float flow = sin(uTime * 2.0 + aTreePos.y * 0.5) * 0.05;
    pos.x += flow;
    pos.z += flow;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    // Very tiny particles
    gl_PointSize = (25.0 * aRandom + 10.0) * (1.0 / -mvPosition.z);
    
    vAlpha = 0.8 + 0.2 * sin(uTime * 3.0 + aRandom * 10.0);
    vColor = aColor; 
  }
`;

const fragmentShader = `
  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    vec2 cxy = 2.0 * gl_PointCoord - 1.0;
    float r = dot(cxy, cxy);
    if (r > 1.0) discard;

    float glow = 1.0 - r;
    glow = pow(glow, 2.0);

    gl_FragColor = vec4(vColor, vAlpha * glow);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

interface RibbonsProps {
  treeState: TreeMorphState;
}

const Ribbons: React.FC<RibbonsProps> = ({ treeState }) => {
  const count = 3000; // Number of particles in the ribbons
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  const [positions, scatterPositions, colors, randoms] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const scatter = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const rand = new Float32Array(count);

    const height = 10;
    const baseRadius = 4.2; // Slightly larger than foliage
    const spirals = 2; // Two ribbons
    const loops = 4.5; // How many times it wraps around

    for (let i = 0; i < count; i++) {
      const ribbonIndex = i % 2; // 0 for Red, 1 for White
      
      // Normalized height (0 to 1)
      const t = Math.random(); 
      const y = t * height;
      
      // Radius tapers as we go up
      const r = (1 - t) * baseRadius;
      
      // Spiral angle
      // Offset by PI for the second ribbon so they are opposite
      const angleOffset = ribbonIndex * Math.PI;
      const theta = (t * loops * Math.PI * 2) + angleOffset;

      // Add some randomness to width (make it a ribbon, not a line)
      const spread = (Math.random() - 0.5) * 0.3; 
      
      // Tree Position
      pos[i * 3] = (r * Math.cos(theta)) + spread * Math.cos(theta);
      pos[i * 3 + 1] = y + spread; // also spread vertically slightly
      pos[i * 3 + 2] = (r * Math.sin(theta)) + spread * Math.sin(theta);

      // Scatter Position (Chaotic strings)
      const sr = 10 + Math.random() * 10;
      const sTheta = Math.random() * Math.PI * 2;
      const sPhi = Math.acos(2 * Math.random() - 1);
      scatter[i * 3] = sr * Math.sin(sPhi) * Math.cos(sTheta);
      scatter[i * 3 + 1] = sr * Math.sin(sPhi) * Math.sin(sTheta);
      scatter[i * 3 + 2] = sr * Math.cos(sPhi);

      // Color
      const c = new THREE.Color();
      if (ribbonIndex === 0) {
        c.set('#ff0033'); // Red
      } else {
        c.set('#ffffff'); // White
      }
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;

      rand[i] = Math.random();
    }
    return [pos, scatter, col, rand];
  }, []);

  useFrame((state, delta) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      const targetMix = treeState === TreeMorphState.TREE_SHAPE ? 1 : 0;
      materialRef.current.uniforms.uMix.value = THREE.MathUtils.lerp(
        materialRef.current.uniforms.uMix.value,
        targetMix,
        delta * 2
      );
    }
  });

  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uMix: { value: 0 },
  }), []);

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-aTreePos" count={count} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-aScatterPos" count={count} array={scatterPositions} itemSize={3} />
        <bufferAttribute attach="attributes-aColor" count={count} array={colors} itemSize={3} />
        <bufferAttribute attach="attributes-aRandom" count={count} array={randoms} itemSize={1} />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default Ribbons;