import React from 'react';
import { TreeMorphState } from '../types';

interface OverlayProps {
  treeState: TreeMorphState;
  onToggle: () => void;
}

const Overlay: React.FC<OverlayProps> = ({ treeState, onToggle }) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10">
      
      {/* Header */}
      <div className="flex flex-col items-center md:items-start text-center md:text-left">
        <h1 className="text-gold-metallic font-serif text-3xl md:text-5xl font-bold tracking-wider drop-shadow-lg">
          XIE WEIDING
        </h1>
        <p className="text-gold-light/60 font-sans text-xs md:text-sm tracking-[0.3em] uppercase mt-2">
          Haute Couture Christmas Collection
        </p>
      </div>

      {/* Control Area */}
      <div className="flex flex-col items-center pb-8 md:pb-0 pointer-events-auto">
        <button
          onClick={onToggle}
          className={`
            group relative px-8 py-3 overflow-hidden rounded-full 
            border border-gold-metallic/30 bg-black/20 backdrop-blur-md
            transition-all duration-500 hover:border-gold-metallic hover:bg-emerald-deep/40
          `}
        >
          <span className={`
            absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-gold-metallic/10 to-transparent
            translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000
          `} />
          
          <span className="relative font-serif text-gold-light tracking-widest text-sm md:text-base">
            {treeState === TreeMorphState.SCATTERED ? 'ASSEMBLE' : 'DISPERSE'}
          </span>
        </button>

        <div className="mt-4 flex gap-2">
           <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${treeState === TreeMorphState.SCATTERED ? 'bg-gold-metallic' : 'bg-white/20'}`} />
           <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-500 ${treeState === TreeMorphState.TREE_SHAPE ? 'bg-gold-metallic' : 'bg-white/20'}`} />
        </div>
      </div>
    </div>
  );
};

export default Overlay;