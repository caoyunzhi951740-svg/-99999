import React, { useMemo, useRef, useLayoutEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { TreeMorphState, OrnamentData } from '../types';

interface OrnamentGroupProps {
  treeState: TreeMorphState;
}

// Shiny Golden LOVE Topper Component
const LoveTopper: React.FC<{ position: THREE.Vector3; scale: number; rotationY: number }> = ({ position, scale, rotationY }) => {
    // Shared material for all letters
    const material = useMemo(() => new THREE.MeshStandardMaterial({
        color: "#ffd700",       // Gold
        emissive: "#ffaa00",    // Deep gold glow
        emissiveIntensity: 0.6,
        metalness: 1.0,
        roughness: 0.1,
    }), []);

    // Helper for bar segments
    const Bar = ({ s, p, r = [0,0,0] }: { s: [number, number, number], p: [number, number, number], r?: [number, number, number] }) => (
        <mesh material={material} position={p} rotation={new THREE.Euler(...r)}>
            <boxGeometry args={s} />
        </mesh>
    );

    return (
        <group position={position} scale={scale} rotation={[0, rotationY, 0]}>
            {/* Scale down the group to fit the topper size */}
            <group scale={0.35}>
                
                {/* L - Top Left */}
                <group position={[-1.1, 1.1, 0]}>
                    <Bar s={[0.3, 1.8, 0.3]} p={[-0.5, 0, 0]} />
                    <Bar s={[1.2, 0.3, 0.3]} p={[0, -0.75, 0]} />
                </group>

                {/* O - Top Right */}
                <group position={[1.1, 1.1, 0]}>
                    <mesh material={material}>
                        <torusGeometry args={[0.8, 0.18, 16, 32]} />
                    </mesh>
                </group>

                {/* V - Bottom Left */}
                <group position={[-1.1, -1.1, 0]}>
                    {/* Fixed rotation to form a proper V shape (\ /) instead of lambda (^ / \) */}
                    <Bar s={[0.3, 1.9, 0.3]} p={[-0.35, 0, 0]} r={[0, 0, 0.35]} /> 
                    <Bar s={[0.3, 1.9, 0.3]} p={[0.35, 0, 0]} r={[0, 0, -0.35]} />
                </group>

                {/* E - Bottom Right */}
                <group position={[1.1, -1.1, 0]}>
                    <Bar s={[0.3, 1.8, 0.3]} p={[-0.6, 0, 0]} />
                    <Bar s={[1.2, 0.3, 0.3]} p={[0, 0.75, 0]} />
                    <Bar s={[1.0, 0.3, 0.3]} p={[-0.1, 0, 0]} />
                    <Bar s={[1.2, 0.3, 0.3]} p={[0, -0.75, 0]} />
                </group>

            </group>

            {/* Inner Sparkle Light */}
            <pointLight distance={6} intensity={4} color="#ffeebb" decay={2} />
            
            {/* Center Core Gem/Connector (Optional, adds density) */}
            <mesh scale={0.2}>
                <octahedronGeometry />
                <meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={2} />
            </mesh>
        </group>
    );
}

const Ornaments: React.FC<OrnamentGroupProps> = ({ treeState }) => {
  const boxCount = 150;
  const sphereCount = 200;

  const boxMeshRef = useRef<THREE.InstancedMesh>(null);
  const sphereMeshRef = useRef<THREE.InstancedMesh>(null);
  
  // --- Data Generation ---
  const { boxData, sphereData, starData } = useMemo(() => {
    const generateData = (count: number, type: 'box' | 'sphere'): OrnamentData[] => {
      const data: OrnamentData[] = [];
      const height = 10;
      const baseRadius = 4;

      for (let i = 0; i < count; i++) {
        // Tree Position
        const y = Math.random() * height * 0.9;
        const relativeY = y / height;
        const r = (1 - relativeY) * baseRadius * (0.8 + Math.random() * 0.4);
        const theta = Math.random() * Math.PI * 2;

        const tx = r * Math.cos(theta);
        const tz = r * Math.sin(theta);
        
        // Scatter Position
        const sr = 12 + Math.random() * 8;
        const sTheta = Math.random() * Math.PI * 2;
        const sPhi = Math.acos(2 * Math.random() - 1);
        const sx = sr * Math.sin(sPhi) * Math.cos(sTheta);
        const sy = sr * Math.sin(sPhi) * Math.sin(sTheta);
        const sz = sr * Math.cos(sPhi);

        const scale = type === 'box' ? 0.3 + Math.random() * 0.3 : 0.2 + Math.random() * 0.2;
        
        const rotation: [number, number, number] = [
            Math.random() * Math.PI, 
            Math.random() * Math.PI, 
            Math.random() * Math.PI
        ];

        const colors = ['#d4af37', '#b8860b', '#cd7f32', '#0f392b']; 
        const color = colors[Math.floor(Math.random() * colors.length)];

        data.push({
          type,
          tree: [tx, y, tz],
          scatter: [sx, sy, sz],
          scale,
          rotation,
          color,
        });
      }
      return data;
    };

    const star: OrnamentData = {
        type: 'star',
        tree: [0, 10.5, 0], // Slightly higher for the LOVE topper
        scatter: [0, 20, 0],
        scale: 1, 
        rotation: [0,0,0],
        color: '#ffffff'
    };

    return {
      boxData: generateData(boxCount, 'box'),
      sphereData: generateData(sphereCount, 'sphere'),
      starData: star
    };
  }, []);

  // --- Animation Logic ---
  const tempObj = new THREE.Object3D();
  const tempColor = new THREE.Color();
  const animRef = useRef({ val: 0 }); 

  useFrame((state, delta) => {
    const target = treeState === TreeMorphState.TREE_SHAPE ? 1 : 0;
    const speed = 2.5;
    animRef.current.val += (target - animRef.current.val) * speed * delta;
    
    const t = animRef.current.val;
    const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    // --- Update Boxes ---
    if (boxMeshRef.current) {
      boxData.forEach((data, i) => {
        const { tree, scatter, rotation, scale } = data;
        tempObj.position.set(
          THREE.MathUtils.lerp(scatter[0], tree[0], ease),
          THREE.MathUtils.lerp(scatter[1], tree[1], ease),
          THREE.MathUtils.lerp(scatter[2], tree[2], ease)
        );
        tempObj.rotation.set(
          rotation[0] + state.clock.elapsedTime * 0.1 * (1-ease), 
          rotation[1] + state.clock.elapsedTime * 0.15 * (1-ease), 
          rotation[2]
        );
        tempObj.scale.setScalar(scale);
        tempObj.updateMatrix();
        boxMeshRef.current!.setMatrixAt(i, tempObj.matrix);
      });
      boxMeshRef.current.instanceMatrix.needsUpdate = true;
    }

    // --- Update Spheres ---
    if (sphereMeshRef.current) {
      sphereData.forEach((data, i) => {
        const { tree, scatter, scale } = data;
        const lightEase = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        tempObj.position.set(
            THREE.MathUtils.lerp(scatter[0], tree[0], lightEase),
            THREE.MathUtils.lerp(scatter[1], tree[1], lightEase),
            THREE.MathUtils.lerp(scatter[2], tree[2], lightEase)
        );
        tempObj.scale.setScalar(scale);
        tempObj.updateMatrix();
        sphereMeshRef.current!.setMatrixAt(i, tempObj.matrix);
      });
      sphereMeshRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  // Initial Color Setup
  useLayoutEffect(() => {
    if (boxMeshRef.current) {
        boxData.forEach((d, i) => {
            tempColor.set(d.color);
            boxMeshRef.current!.setColorAt(i, tempColor);
        });
        boxMeshRef.current.instanceColor!.needsUpdate = true;
    }
    if (sphereMeshRef.current) {
        sphereData.forEach((d, i) => {
            tempColor.set(d.color);
            sphereMeshRef.current!.setColorAt(i, tempColor);
        });
        sphereMeshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [boxData, sphereData]);

  // Hook for Love topper animation
  const TopperWrapper = () => {
      const groupRef = useRef<THREE.Group>(null);
      useFrame((state, delta) => {
          if (!groupRef.current) return;
          const { tree, scatter } = starData;
          const t = animRef.current.val;
          const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

          groupRef.current.position.set(
            THREE.MathUtils.lerp(scatter[0], tree[0], ease),
            THREE.MathUtils.lerp(scatter[1], tree[1], ease),
            THREE.MathUtils.lerp(scatter[2], tree[2], ease)
          );
          
          // Rotate the whole topper slowly
          groupRef.current.rotation.y += delta * 0.3;
          
          // Gentle Pulse
          const pulse = 1 + Math.sin(state.clock.elapsedTime * 1.5) * 0.05;
          groupRef.current.scale.setScalar(pulse);
      });

      return (
        <group ref={groupRef}>
             <LoveTopper position={new THREE.Vector3(0,0,0)} scale={1} rotationY={0} />
        </group>
      )
  }

  return (
    <group>
        <instancedMesh ref={boxMeshRef} args={[undefined, undefined, boxCount]} castShadow receiveShadow>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial metalness={0.6} roughness={0.2} envMapIntensity={1.5} />
        </instancedMesh>

        <instancedMesh ref={sphereMeshRef} args={[undefined, undefined, sphereCount]} castShadow receiveShadow>
            <sphereGeometry args={[1, 32, 32]} />
            <meshStandardMaterial metalness={0.9} roughness={0.1} envMapIntensity={2.0} />
        </instancedMesh>

        <TopperWrapper />
    </group>
  );
};

export default Ornaments;