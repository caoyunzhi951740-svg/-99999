import React from 'react';
import { TreeMorphState } from '../types';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import Ribbons from './Ribbons';

interface ChristmasTreeProps {
  treeState: TreeMorphState;
}

const ChristmasTree: React.FC<ChristmasTreeProps> = ({ treeState }) => {
  return (
    <group>
      {/* The main green volume */}
      <Foliage treeState={treeState} />
      
      {/* Red and White particle ribbons */}
      <Ribbons treeState={treeState} />

      {/* The shiny decorations and Snowflake */}
      <Ornaments treeState={treeState} />
      
      {/* Internal Glow for tree center */}
      <pointLight position={[0, 4, 0]} intensity={treeState === TreeMorphState.TREE_SHAPE ? 1 : 0.1} color="#ffaa00" distance={8} decay={2} />
    </group>
  );
};

export default ChristmasTree;