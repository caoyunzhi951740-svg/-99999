export enum TreeMorphState {
  SCATTERED = 'SCATTERED',
  TREE_SHAPE = 'TREE_SHAPE',
}

export interface DualPosition {
  tree: [number, number, number];
  scatter: [number, number, number];
  scale: number;
  rotation: [number, number, number];
}

export interface OrnamentData extends DualPosition {
  type: 'box' | 'sphere' | 'star';
  color: string;
}
